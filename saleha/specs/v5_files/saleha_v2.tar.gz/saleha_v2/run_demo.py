#!/usr/bin/env python3
"""
Saleha v2 — End-to-End Demo Runner

Demonstrates the full loop:
  1. Show the v1 output (buggy) — Python linter catches 3 failures
  2. Show the v2 output (corrected) — Python linter: 5/5 pass
  3. Compile v2 with iverilog
  4. Run self-checking testbench — 28/28 pass

Run:  python3 run_demo.py

Requires: iverilog (Ubuntu/Debian: apt install iverilog)
"""

import subprocess
import sys
from pathlib import Path
from saleha_prompt import lint_saleha_output

ROOT = Path(__file__).parent
DIV = "═" * 70
SUB = "─" * 70


def banner(text):
    print(f"\n{DIV}\n  {text}\n{DIV}")


def lint_file(path, expected_pass):
    print(f"\n  File: {path.name}")
    print(f"  {SUB}")
    rtl = path.read_text()
    results = lint_saleha_output(rtl)
    fails = 0
    for check, (passed, msg) in results.items():
        icon = "✓" if passed else "✗"
        print(f"   [{icon}] {check:28}  {msg}")
        if not passed:
            fails += 1
    verdict = "CLEAN" if fails == 0 else f"{fails} FAILURE(S)"
    status_ok = (fails == 0) == expected_pass
    print(f"  {SUB}")
    print(f"  VERDICT: {verdict}   [expected {'pass' if expected_pass else 'fail'}: "
          f"{'✓' if status_ok else '✗ UNEXPECTED'}]")
    return status_ok, fails


def run(cmd, cwd=None):
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr


def main():
    print(DIV)
    print("  SALEHA v2 — RIGHTEOUS BY DESIGN, PROVEN BY PROOF")
    print("  End-to-end demonstration of the hardened RTL pipeline")
    print(DIV)

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 1: lint the original buggy v1 output
    # ─────────────────────────────────────────────────────────────────────
    banner("STAGE 1 — Lint the v1 output (the FIFO you pasted)")
    print("  Expectation: Saleha's hardened linter must REJECT this file")
    print("  because of the sync/async reset contradiction + missing blocks.")
    v1_ok, v1_fails = lint_file(ROOT / "fifo_v1_original.sv", expected_pass=False)

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 2: lint the corrected v2 output
    # ─────────────────────────────────────────────────────────────────────
    banner("STAGE 2 — Lint the v2 output (regenerated under hardened prompt)")
    print("  Expectation: All 5 rules must pass.")
    v2_ok, v2_fails = lint_file(ROOT / "fifo_corrected.sv", expected_pass=True)

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 3: compile v2 with iverilog
    # ─────────────────────────────────────────────────────────────────────
    banner("STAGE 3 — Compile with iverilog (SystemVerilog 2012)")
    rc, out, err = run("which iverilog")
    if rc != 0:
        print("  [SKIP] iverilog not installed.")
        print("          Ubuntu: sudo apt install iverilog")
        compile_ok = None
    else:
        rc, out, err = run("iverilog -g2012 -o tb tb_fifo.sv fifo_corrected.sv", cwd=ROOT)
        if rc == 0 and not err:
            print("  [✓] Clean compile. No warnings.")
            compile_ok = True
        else:
            print(f"  [✗] Compile failed:\n{out}\n{err}")
            compile_ok = False

    # ─────────────────────────────────────────────────────────────────────
    # STAGE 4: run the self-checking testbench
    # ─────────────────────────────────────────────────────────────────────
    banner("STAGE 4 — Run self-checking testbench")
    if compile_ok:
        rc, out, _ = run("vvp tb", cwd=ROOT)
        # show only the test summary lines
        for line in out.splitlines():
            if any(tag in line for tag in ["TEST", "PASS", "FAIL", "RESULTS", "VERDICT", "════"]):
                print(f"  {line}")
        sim_ok = "RIGHTEOUS" in out
    else:
        print("  [SKIP] compile failed or iverilog unavailable.")
        sim_ok = None

    # ─────────────────────────────────────────────────────────────────────
    # FINAL REPORT
    # ─────────────────────────────────────────────────────────────────────
    banner("FINAL REPORT")
    print(f"  Stage 1 — v1 correctly rejected:   {'✓' if v1_ok else '✗'} ({v1_fails} bugs caught)")
    print(f"  Stage 2 — v2 linter clean:         {'✓' if v2_ok else '✗'}")
    print(f"  Stage 3 — v2 compiles:             {'✓' if compile_ok else '— skipped' if compile_ok is None else '✗'}")
    print(f"  Stage 4 — v2 testbench passes:     {'✓' if sim_ok else '— skipped' if sim_ok is None else '✗'}")

    all_green = v1_ok and v2_ok and (compile_ok is not False) and (sim_ok is not False)
    print(f"\n  {'═' * 66}")
    if all_green:
        print("  SALEHA v2 PIPELINE: OPERATIONAL ✓")
        print("  Hardened prompt catches bugs. Corrected RTL is righteous.")
    else:
        print("  SALEHA v2 PIPELINE: ISSUES PRESENT — review failures above.")
    print(f"  {'═' * 66}\n")

    return 0 if all_green else 1


if __name__ == "__main__":
    sys.exit(main())
